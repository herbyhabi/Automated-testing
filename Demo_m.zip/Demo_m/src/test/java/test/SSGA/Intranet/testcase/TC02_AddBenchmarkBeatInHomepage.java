package test.SSGA.Intranet.testcase;

import com.relevantcodes.extentreports.LogStatus;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import test.SSGA.Intranet.factory.CustomizeAssertion;
import test.SSGA.Intranet.factory.CustomizeFunctions;
import test.SSGA.Intranet.factory.ReusableFunctions;
import test.SSGA.Intranet.factory.TestBasis;
import test.SSGA.Intranet.pages.EditIntranetArticlePage;
import test.SSGA.Intranet.pages.Intranet_Pages.HomePage;
import test.SSGA.Intranet.pages.SSGAIntranetHomePage;
import test.SSGA.Intranet.pages.WebsitesPage;


public class TC02_AddBenchmarkBeatInHomepage extends TestBasis {
    ReusableFunctions reusableFunctions;
    WebsitesPage websitesPage;
    CustomizeFunctions customizeFunctions;
    SSGAIntranetHomePage ssgaIntranetHomePage;
    EditIntranetArticlePage editIntranetArticlePage;
    CustomizeAssertion customizeAssertion;
    HomePage homePage;

    /**
     * Description: Add a benchmark beat item and check it is added.
     * //Step 1: Login AEM author
     * //Step 2: Open the SSGA Intranet home page
     * //Step 3: Add a benchmark beat item for monday
     * //Step 4: Enter values in every fields.
     * //Step 5: Run workflow 'Intranet Page Activation'.
     * //Step 6: Go to Intranet site to check home page.
     * //Step 7: Check the URL is correct
     */

    @Test
    public void verify_TC03() throws Exception {
        reusableFunctions = new ReusableFunctions();
        websitesPage = new WebsitesPage();
        customizeFunctions = new CustomizeFunctions();
        ssgaIntranetHomePage = new SSGAIntranetHomePage();
        editIntranetArticlePage = new EditIntranetArticlePage();
        customizeAssertion = new CustomizeAssertion();
        homePage = new HomePage();


        String linkURL = "   /content/dam/intranet/documents/org-chart/Global-Trading-Team-20170116.pdf";
        int newWindowOrNotIndex = 1; // 0 is Yes, 1 is No.
        String heroTitle = "Monday Title for QA Automation" + reusableFunctions.getFigures(3);
        String description = "Monday Description for QA Automation" +reusableFunctions.getFigures(3);
        String textOnBtn = "VIEW MORE" +reusableFunctions.getFigures(3);
        int labelTitleIndex = 0; //0 means the first one in the label list
        String imgPath = "   /content/dam/intranet/images/icon_clock.png";


        test.log(LogStatus.INFO,"//Step 1: Login AEM author");
        reusableFunctions.login();
        Thread.sleep(5000);

        test.log(LogStatus.INFO,"//Step 2: Open the SSGA Intranet home page");
        int index = reusableFunctions.locateElementByText(websitesPage.listOfItemForIntranet,"SSGA Intranet Home");
        customizeFunctions.click(websitesPage.listOfItemForIntranet.get(index),"Click on SSGA Intranet home item");
        Thread.sleep(1000);
        customizeFunctions.doubleClick(websitesPage.listOfItemForIntranet.get(index),"Open the SSGA Intranet Home page");
        Thread.sleep(15000);

        reusableFunctions.judgeCurrentWindow();
        driver.switchTo().frame("cq-cf-frame");

        test.log(LogStatus.INFO,"//Step 3: Add a benchmark beat item for monday");
        customizeFunctions.doubleClick(ssgaIntranetHomePage.iconOfBenchmarkBeat,"Double click on The benchmark beat icon to open the component");
        Thread.sleep(10000);

        customizeFunctions.scrollToElement(ssgaIntranetHomePage.btnOfAddItem,"Scroll to Add Item button");

        //Delete the last Benchmark Beat item.
        customizeFunctions.click(ssgaIntranetHomePage.listOfRemoveIconBenchmarkBeatItem.get(ssgaIntranetHomePage.listOfRemoveIconBenchmarkBeatItem.size()-1),"Remove the last Benchmark Beat item");

        customizeFunctions.clickByJavascript(ssgaIntranetHomePage.btnOfAddItem,"Click on the Add Item button");
        test.log(LogStatus.INFO,"//Step 4: Enter value with every fields.");

        //enter the url, choose yes or no, enter the hero title, description, text on button, image path. choose a label.
        String labelName = ssgaIntranetHomePage.editBenchmarkBeatItem(ssgaIntranetHomePage.listOfBenchmarkBeatItem.size(),linkURL,newWindowOrNotIndex,heroTitle,description,textOnBtn,labelTitleIndex,imgPath);

        customizeFunctions.click(ssgaIntranetHomePage.btnOfOK,"Click on OK button");
        Thread.sleep(8000);

        driver.switchTo().defaultContent();

        test.log(LogStatus.INFO,"//Step 5: Run workflow 'Intranet Page Activation'.");
        editIntranetArticlePage.runWorkflowInAEM("Intranet Page Activation");

        test.log(LogStatus.INFO,"//Step 6: Go to Intranet site to check the label, title the home page.");
        navigateToIntranetSite();
        Thread.sleep(8000);

        //To get the weekday for today
        int weekday = reusableFunctions.getTheCurrentWeekDay();
        ssgaIntranetHomePage.verifyBenchmarkBeatItemForMonday(weekday,labelName,heroTitle,description);

        test.log(LogStatus.INFO,"//Step 7: Check the URL is correct");

        //To get the expected link for matching with the actual link.
        String expectedLink = ssgaIntranetHomePage.splitLinkURl(linkURL);
        WebElement actualLinkElement = homePage.linkOfURLInHero;
        if(weekday == 1)
            actualLinkElement =homePage.linkOfURLInHero;
        if(weekday == 2)
            actualLinkElement =homePage.linkOfURL5;
        if(weekday == 3)
            actualLinkElement =homePage.linkOfURL4;
        if(weekday == 4)
            actualLinkElement =homePage.linkOfURL3;
        if(weekday == 5 || weekday == 6 || weekday == 0)
            actualLinkElement =homePage.linkOfURL2;
        customizeAssertion.assertTrue(actualLinkElement.getAttribute("href").contains(expectedLink),"The URL is correct");

        //For open new window field,if choose on option, the 'target' attribute of a label is '_self'. Otherwise, the value is '_blank'
        customizeAssertion.assertTrue(actualLinkElement.getAttribute("target").contains("_self"),"The link will be opened in the same tab");

        eventualAssert();
    }
}
