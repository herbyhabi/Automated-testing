package test.SSGA.Intranet.factory;
import com.relevantcodes.extentreports.LogStatus;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import utilities.Log;
import org.apache.commons.io.FileUtils;
import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;

public class CustomizeAssertion extends TestBasis {

    String errorImagePath = ".\\test-output\\errorScreenshot";
    String returnPath = ".\\errorScreenshot";

    /**
     * Determine if the element exists
     * @param element enter the location of element
     * @return true or false
     * @author He, Ying
     */
    public boolean doesElementExist(WebElement element){
        TestBasis.driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        try{
            element.isDisplayed();

        }catch (NoSuchElementException e){
            return false;
        }
        return true;
    }


    public boolean assertTrue(boolean condition, String message){
        try{
            Assert.assertTrue(condition,message);
            return true;
        }catch (AssertionError e){
            String path = errorScreenshot((TakesScreenshot) driver);
            printErrorMsg(path,message);
            return false;
        }

    }

    public boolean assertFalse(boolean condition, String message){
        try{
            Assert.assertFalse(condition,message);
            return false;
        }catch (AssertionError e){
            String path = errorScreenshot((TakesScreenshot) driver);
            printErrorMsg(path,message);
            return true;
        }


    }


    public boolean assertEquals(String actual, String expected, String message){
        try{
            Assert.assertEquals(actual,expected,message);
            return true;
        }catch (AssertionError e){
            String path = errorScreenshot((TakesScreenshot) driver);
            printErrorMsg(path,message,actual,expected);
            return false;
        }
    }

    public boolean assertNotEquals(String actual, String expected, String message){
        try{
            Assert.assertNotEquals(actual,expected,message);
            return true;
        }catch (AssertionError e){
            String path = errorScreenshot((TakesScreenshot) driver);
            printErrorMsg(path,message,actual,expected);
            return false;
        }
    }



    public String errorScreenshot(TakesScreenshot name){
        File file = name.getScreenshotAs(OutputType.FILE);
        Date date = new Date();
        DateFormat format = new SimpleDateFormat("yyyyMMddHHmmss");
        String timestamp = format.format(date);

        try {
        System.out.println("save error screenshot path is:" + errorImagePath );
            FileUtils.copyFile(file, new File(errorImagePath + "\\" + timestamp + ".png"));
            FileUtils.copyFile(file, new File(returnPath + "\\" + timestamp + ".png"));
        }catch (IOException e){
            System.out.println("Can not save screenshot");
            return "";
        }finally {
            return returnPath+ "\\" + timestamp + ".png";
        }

    }



    public void printErrorMsg(String path,String message, String actual, String expected){
        Log.error(message+path);
        test.log(LogStatus.FAIL, "\n Actual = "+actual+" Expected = "+expected + test.addScreenCapture(path));
    }

    public void printErrorMsg(String path, String message) {
        test.log(LogStatus.FAIL, message + path);
        Log.error(message);
        test.log(LogStatus.FAIL, test.addScreenCapture(path) );
    }
}
