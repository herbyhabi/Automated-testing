package test.SSGA.Intranet.testdata;


public class CommonData {

    //Username and Password
    public static String USERNAME = "a804446";
    public static String PASSWORD = "testuser";

    //AEM URL
    public static String AEM_DEV = "http://gvcmsdev53:4502/siteadmin#/content/ssga-intranet";
    public static String AEM_DEVX = "http://gvcmsdvi53:4502/siteadmin#/content/ssga-intranet";
    public static String AEM_UAT = "http://gvcmsuat53:4502/siteadmin#/content/ssga-intranet";

    //Intranet Site URL
    public static String INTRANET_DEV = "http://www-dev.ssga.statestr.com/index.html";
    public static String INTRANET_DEVX = "http://ssga4.intranet.devx.ssga.statestr.com/home.html";
    public static String INTRANET_UAT = "http://www-test.ssga.statestr.com/index.html";
    public static String INTRANET_PROD = "http://www-test.ssga.statestr.com/index.html";
}
