package test.SSGA.Intranet.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import test.SSGA.Intranet.factory.CustomizeAssertion;
import test.SSGA.Intranet.factory.CustomizeFunctions;
import test.SSGA.Intranet.factory.TestBasis;
import test.SSGA.Intranet.pages.Intranet_Pages.HomePage;
import java.util.List;


public class SSGAIntranetHomePage extends BasicPage {

    //Icon: The Benchmark Beat icon
    @FindBy(xpath="//span[@class = 'mark']")
    public WebElement iconOfBenchmarkBeat;

    /**
     * element in Benchmark Beat component
     *
     */

    //List: Benchmark Beat Details item
    @FindBy(xpath="(//td[@class = 'x-table-layout-cell cq-multifield-itemct'])")
    public List<WebElement> listOfBenchmarkBeatItem;

    //Button: Add item button
    @FindBy(xpath="//span[@class = ' x-btn-text']")
    public WebElement btnOfAddItem;

    //List: Yes, No options in the Open New Window field.
    @FindBy(xpath="//div[contains(@class, 'x-combo-list-item')]")
    public List<WebElement> listOfOpenNewWindowOptions;

    //List: Label trigger Selector
    @FindBy(xpath="//img[@class = 'arrow-trigger']")
    public List<WebElement> selectorOfLabel;

    //List: Options list for label field.
    @FindBy(xpath="//ul[@class = 'x-tree-root-ct x-tree-lines']//li")
    public List<WebElement> listOfLabelOptions;

    //Button: OK button
    @FindBy(xpath="(//td[@class = 'x-toolbar-right']//button[@class = ' x-btn-text'])[1]")
    public WebElement btnOfOK;

    //List; Remove Benchmark Beat item's icon
    @FindBy(xpath="//button[@class = ' x-btn-text cq-multifield-remove']")
    public List<WebElement> listOfRemoveIconBenchmarkBeatItem;

    //List: Remove label icon.
    @FindBy(xpath="//div[@class = 'taglabel-tool taglabel-tool-remove']")
    public List<WebElement> listOfRemoveLabelIcon;

    //Tab: Highlight
    @FindBy(xpath="(//span[@class = 'x-tab-strip-text '])[2]")
    public WebElement tabOfHighlight;

    //Checkbox: Hide in highlight tab
    @FindBy(xpath="//input[@type= 'checkbox' and @name = './hideHighlight' ]")
    public WebElement checkboxOfHide;

    //Input: Title input in highlight tab
    @FindBy(xpath="(//div[@class = 'x-panel x-panel-noborder x-form-label-left']//input[@type = 'text'])[1]")
    public WebElement inputOfTitle;

    /******************/

    /**
     * Link List component
     *
     */

    //Selector: Color theme field
    @FindBy(xpath="((//div[@class = 'x-form-item x-tab-item'])[2]//input)[2]")
    public WebElement selectorOfColorTheme;

    //List: Options list for color theme
    @FindBy(xpath="//div[contains(@class, 'x-combo-list-item') and text()='teal' or text()='sage']")
    public List<WebElement> listOfOptionsForColorTheme;

    //Button: Edit button in the link list section
    @FindBy(xpath="((//div[@class = 'x-panel-body x-panel-body-noheader']//div[@class = 'x-toolbar x-small-editor x-toolbar-layout-ct']//tr[@class = 'x-toolbar-left-row'])[2]//td)[2]//button")
    public WebElement btnOfEditLinkList;

    //Button: Add Item button
    @FindBy(xpath="//span[contains(@class, 'cq-tbtn cq-tbtn-medium')]")
    public WebElement btnOfAddItemInLinkList;

    //List: List of Links item.
    @FindBy(xpath="(//div[@class = 'x-tab-panel-body x-tab-panel-body-top']//div[@class = 'x-form-item x-tab-item']//div[@class = 'x-panel-body x-panel-body-noheader'])")
    public List<WebElement> listOfLinkListItem;

    //List: Options of opening a new tab
    @FindBy(xpath="(//div[@class = 'x-combo-list-inner'])//div[contains(@class, 'x-combo-list-item') and text() = 'yes' or text() = 'no']")
    public List<WebElement> listOfOptionsForOpenNewTab;

    //Button: OK button
    @FindBy(xpath="//table[@class = 'x-btn cq-btn-ok x-btn-noicon']//button")
    public WebElement btnOfOKInLinkList;

    //Icon: Remove item icon
    @FindBy(xpath="//button[@class = ' x-btn-text cq-multifield-remove']")
    public List<WebElement> listOfRemoveIconLinkList;

    /*******************/



    public List<WebElement> getTheSpecifiedBenchmarkBeatItem(int num) {
        String prefixXpath = "(//td[@class = 'x-table-layout-cell cq-multifield-itemct'])";
        String suffixXpath = "//div[@class = 'x-form-item ']//input";
        List<WebElement> targetList = TestBasis.driver.findElements(By.xpath(prefixXpath + "[" + num + "]" + suffixXpath));
        return targetList;
    }

    /**
     *  Edit a specified benchmark beat item
     * @param benchmarkItem select which item you want to change
     * @param linkURL enter the link URL
     * @param newWindowOrNotIndex 0 is yes, 1 is no
     * @param heroTitle enter a hero title
     * @param description enter a description
     * @param textOnBtn enter a text on button
     * @param labelTitleIndex label type. for example: 0 is the fist option in the label type list.
     * @param imgPath enter a image path
     * @throws Exception
     */
    public String editBenchmarkBeatItem(int benchmarkItem,
                                      String linkURL,
                                      int newWindowOrNotIndex,
                                      String heroTitle,
                                      String description,
                                      String textOnBtn,
                                      int labelTitleIndex,
                                      String imgPath ) throws Exception{
        CustomizeFunctions customizeFunctions = new CustomizeFunctions();

        List<WebElement> specifiedItem  = getTheSpecifiedBenchmarkBeatItem(benchmarkItem);
        customizeFunctions.input(specifiedItem.get(0),linkURL,"Enter the link URL");
        customizeFunctions.click(specifiedItem.get(2),"Click on 'Open New Windows' field");
        Thread.sleep(1000);
        customizeFunctions.click(listOfOpenNewWindowOptions.get(newWindowOrNotIndex),"Choose yes option in the Open New Window field");
        specifiedItem.get(3).clear();
        customizeFunctions.input(specifiedItem.get(3),heroTitle,"Enter a hero title");

        specifiedItem.get(4).clear();
        customizeFunctions.input(specifiedItem.get(4),description,"Enter the description");

        specifiedItem.get(5).clear();
        customizeFunctions.input(specifiedItem.get(5),textOnBtn,"Enter a text for button");

        customizeFunctions.click(selectorOfLabel.get(selectorOfLabel.size()-1),"Click on label selector");

        String labelName = getLabelName(labelTitleIndex);
        customizeFunctions.click(listOfLabelOptions.get(labelTitleIndex),"Choose employee label");
        customizeFunctions.input(specifiedItem.get(7),imgPath,"Enter image path");

        return labelName;
    }

    /**
     * Edit a link item. change all fields
     * @param linkItemNum the first item's number is 2. the second is 3, etc.
     * @param title the link title
     * @param LinkURL the link url
     * @param optionNum  0 means yes, 1 means no
     */
    public void editLinkItemWithArticleLink(int linkItemNum,String title, String LinkURL, int optionNum) throws InterruptedException {
        CustomizeFunctions customizeFunctions = new CustomizeFunctions();

        List<WebElement> specifiedList = locateTheSpecifiedLinksItem(linkItemNum);
        customizeFunctions.input(specifiedList.get(0),title,"Enter the title for this link");

        String[] s = LinkURL.split("/");
        int i =1;
        do {
            customizeFunctions.input(specifiedList.get(1),"/","");
            Thread.sleep(2500);
            customizeFunctions.input(specifiedList.get(1),s[i],s[i]);
            i = i+1;
        }while (i <s.length);
        specifiedList.get(1).sendKeys(Keys.ENTER);

        customizeFunctions.click(specifiedList.get(3),"Click on selector for opening a new tab");
        customizeFunctions.click(listOfOptionsForOpenNewTab.get(optionNum),"choose yes option");
        customizeFunctions.click(btnOfOKInLinkList,"Click on OK button");
        Thread.sleep(2000);

    }


    /**
     * Verify the last item(Monday) fields in the site.
     * @param weekday
     * @param expectedLabel
     * @param expectedHeroTitle
     * @param expectedDesc
     */
    public void verifyBenchmarkBeatItemForMonday(int weekday,String expectedLabel, String expectedHeroTitle, String expectedDesc){
        HomePage homePage = new HomePage();
        CustomizeAssertion customizeAssertion = new CustomizeAssertion();
        switch(weekday){
            //weekday = 0 or 6 or 5
            case 0:
            case 6:
            case 5:{
                customizeAssertion.assertEquals(homePage.textOflabTitle2.getText().trim(),expectedLabel.toUpperCase(),"The label2 is shown correctly");
                customizeAssertion.assertEquals(homePage.linkOfURL2.getText().trim(),expectedHeroTitle,"The link2 is equal to hero title");
                break;
            }
            case 4:{
                customizeAssertion.assertEquals(homePage.textOflabTitle3.getText().trim(),expectedLabel.toUpperCase(),"The label3 is shown correctly");
                customizeAssertion.assertEquals(homePage.linkOfURL3.getText().trim(),expectedHeroTitle,"The link3 is equal to hero title");
                break;
            }
            case 3:{
                customizeAssertion.assertEquals(homePage.textOflabTitle4.getText().trim(),expectedLabel.toUpperCase(),"The label4 is shown correctly");
                customizeAssertion.assertEquals(homePage.linkOfURL4.getText().trim(),expectedHeroTitle,"The link4 is equal to hero title");
                break;
            }
            case 2:{
                customizeAssertion.assertEquals(homePage.textOflabTitle5.getText().trim(),expectedLabel.toUpperCase(),"The label5 is shown correctly");
                customizeAssertion.assertEquals(homePage.linkOfURL5.getText().trim(),expectedHeroTitle,"The link5 is equal to hero title");
                break;
            }
            case 1:{
                customizeAssertion.assertEquals(homePage.textOfLabTitle.getText().trim(),expectedLabel.toUpperCase(),"The label1 is shown correctly");
                customizeAssertion.assertEquals(homePage.textOfHeroTitle.getText().trim(),expectedHeroTitle,"The link1 is equal to hero title");
                customizeAssertion.assertEquals(homePage.textOfDescriptionInHero.getText().trim(),expectedDesc,"The description is correct");
                break;
            }
            default: System.out.println("No weekday match!");

        }
    }


    public String getLabelName(int labelNum){
        List<WebElement> listOfLabelName;
        listOfLabelName = TestBasis.driver.findElements(By.xpath("//ul[@class = 'x-tree-root-ct x-tree-lines']//li//a/span"));
        return listOfLabelName.get(labelNum).getText().trim();

    }

    public String splitLinkURl(String linkUrl){
        String[] ss = linkUrl.split("/");
        return ss[ss.length - 1];
    }

    /**
     * According to the weekday for today to locate the hero item.
     * @param weekday
     * @return
     */
    public int locateHeroItem(int weekday){
        int locationNum = -1;
        if (weekday ==1)
            locationNum = listOfBenchmarkBeatItem.size();
        if(weekday ==2)
            locationNum = listOfBenchmarkBeatItem.size()-1;
        if(weekday ==3)
            locationNum = listOfBenchmarkBeatItem.size()-2;
        if(weekday ==4)
            locationNum = listOfBenchmarkBeatItem.size()-3;
        if(weekday == 5 || weekday ==6|| weekday ==0)
            locationNum = listOfBenchmarkBeatItem.size()-4;
        return locationNum;
    }

    public List<WebElement> locateTheSpecifiedLinksItem(int num){
        String prefixPath = "(//div[@class = 'x-tab-panel-body x-tab-panel-body-top']//div[@class = 'x-form-item x-tab-item']//div[@class = 'x-panel-body x-panel-body-noheader'])";
        List<WebElement> targetList = TestBasis.driver.findElements(By.xpath(prefixPath + "[" + num + "]//input"));

        return  targetList;
    }

}
