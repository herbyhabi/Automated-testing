package test.SSGA.Intranet.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class LoginPage extends BasicPage {


    //Input: Username
    @FindBy(xpath="//input[@id = 'username']")
    public WebElement inputOfUsername;

    //Input: Password
    @FindBy(xpath="//input[@id = 'password']")
    public WebElement inputOfPassword;

    //Button: Sign in
    @FindBy(xpath="//button[@type= 'submit']")
    public WebElement btnOfSignIn;
}
