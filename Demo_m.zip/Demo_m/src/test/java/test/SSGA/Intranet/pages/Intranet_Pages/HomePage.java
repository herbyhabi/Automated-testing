package test.SSGA.Intranet.pages.Intranet_Pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import test.SSGA.Intranet.pages.BasicPage;

import java.util.List;

public class HomePage extends BasicPage {

    //List: Header navigate bar menu
    @FindBy(xpath="//header//nav/ul//li")
    public List<WebElement> listOfHeaderMenu;

    /**
     * Hero section
     */
    //Text: lab title
    @FindBy(xpath="//div[@class = 'promo_text']//h3")
    public WebElement textOfLabTitle;

    //Text: Hero Title
    @FindBy(xpath="//div[@class = 'promo_text']//h1")
    public WebElement textOfHeroTitle;

    //Text: Description in hero
    @FindBy(xpath="//div[@class = 'promo_text']//p")
    public WebElement textOfDescriptionInHero;

    //Link: Link url in hero section
    @FindBy(xpath="//div[@class = 'promo_text']//a")
    public WebElement linkOfURLInHero;

    /****************/

    /**
     * The lower section
     */
    //Text: Lab title 2
    @FindBy(xpath="(//div[@id= 'columns_feature']//section)[1]//h3")
    public WebElement textOflabTitle2;

    //Link: URl link 2
    @FindBy(xpath="(//div[@id= 'columns_feature']//section)[1]//a")
    public WebElement linkOfURL2;


    //Text: Lab title 3
    @FindBy(xpath="(//div[@id= 'columns_feature']//section)[2]//h3")
    public WebElement textOflabTitle3;

    //Link: URl link 3
    @FindBy(xpath="(//div[@id= 'columns_feature']//section)[2]//a")
    public WebElement linkOfURL3;

    //Text: Lab title 4
    @FindBy(xpath="(//div[@id= 'columns_feature']//section)[3]//h3")
    public WebElement textOflabTitle4;

    //Link: URl link 4
    @FindBy(xpath="(//div[@id= 'columns_feature']//section)[3]//a")
    public WebElement linkOfURL4;

    //Text: Lab title 5
    @FindBy(xpath="((//div[@id= 'columns_feature']//section)[4]//h3)[1]")
    public WebElement textOflabTitle5;

    //Link: URl link 5
    @FindBy(xpath="((//div[@id= 'columns_feature']//section)[4]//a)[1]")
    public WebElement linkOfURL5;

    //Section: highlight Link section
    @FindBy(xpath="(//div[@id= 'columns_feature']//section)[4]")
    public WebElement sectionOfHighlightLink;
    /***********/

    /**
     * Link list section
     */

    //List: list of links in the link list section
    @FindBy(xpath="(//div[@class = 'column_item'])[2]//ul//li/a")
    public List<WebElement> listOfLinkInLinkList;

    //Panel: Panel of link list section
    @FindBy(xpath="(//div[@class = 'linkListComponent parbase section'])[2]//div")
    public WebElement panelOfLinkListSection;
}

