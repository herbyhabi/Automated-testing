package test.SSGA.Intranet.testcase;

import com.relevantcodes.extentreports.LogStatus;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import test.SSGA.Intranet.factory.*;
import test.SSGA.Intranet.pages.EditIntranetArticlePage;
import test.SSGA.Intranet.pages.Intranet_Pages.HomePage;
import test.SSGA.Intranet.pages.SSGAIntranetHomePage;
import test.SSGA.Intranet.pages.WebsitesPage;

import java.util.List;

public class TC04_AddAndEditLinkList extends TestBasis {
    ReusableFunctions reusableFunctions;
    CustomizeFunctions customizeFunctions;
    WebsitesPage websitesPage;
    SSGAIntranetHomePage ssgaIntranetHomePage;
    EditIntranetArticlePage editIntranetArticlePage;
    HomePage homePage;
    CustomizeAssertion customizeAssertion;
    Functions functions;


    /**
     * Description: 1. Add items into link list with kinds of links. 2. Edit the existing item.
     *
     *
     */


    @Test
    public void verify_TC05() throws Exception {
        reusableFunctions = new ReusableFunctions();
        customizeFunctions = new CustomizeFunctions();
        websitesPage = new WebsitesPage();
        ssgaIntranetHomePage = new SSGAIntranetHomePage();
        editIntranetArticlePage = new EditIntranetArticlePage();
        homePage = new HomePage();
        customizeAssertion = new CustomizeAssertion();
        functions = new Functions();

        String intranetHTMLArticleLink = "/content/ssga-intranet/articles/intranethtmlarticlenotdelete";
        String intranetPDFArticleLink = "/content/ssga-intranet/articles/intranetpdfarticlenotdelete";
        String intranetVideoArticleLink = "/content/ssga-intranet/articles/intranetvideoarticlenotdelete";
        String ssgaSharedArticleLink = "/content/ssga-intranet/articles/sharedcontent/2018/07/ssgasharedarticlenotdelete";
        String externalLink = " https://www.google.com.hk";

        String titleHTML = "Intranet HTML Article " + reusableFunctions.getFigures(3);
        String titlePDF = "Intranet PDF Article " + reusableFunctions.getFigures(3);
        String titleVideo = "Intranet Video Article " + reusableFunctions.getFigures(3);
        String titleShared = "SSGA Shared Article " + reusableFunctions.getFigures(3);
        String titleExternal = "External link - google " + reusableFunctions.getFigures(3);




        test.log(LogStatus.INFO,"//Step 1: Login AEM author");
        reusableFunctions.login();
        Thread.sleep(5000);

        test.log(LogStatus.INFO,"//Step 2: Open the SSGA Intranet home page");
        int index = reusableFunctions.locateElementByText(websitesPage.listOfItemForIntranet,"SSGA Intranet Home");
        customizeFunctions.click(websitesPage.listOfItemForIntranet.get(index),"Click on SSGA Intranet home item");
        Thread.sleep(1000);
        customizeFunctions.doubleClick(websitesPage.listOfItemForIntranet.get(index),"Open the SSGA Intranet Home page");
        Thread.sleep(15000);

        reusableFunctions.judgeCurrentWindow();
        driver.switchTo().frame("cq-cf-frame");

        test.log(LogStatus.INFO,"//Step 3: Open the link list component by clicking on Edit button >> Add various link into the link list");
        customizeFunctions.scrollToElement(ssgaIntranetHomePage.btnOfEditLinkList,"Scroll to the edit button");

        customizeFunctions.clickByJavascript(ssgaIntranetHomePage.btnOfEditLinkList,"Click on Edit button in the link list section");
        Thread.sleep(1000);

        //Before add items,remove some link items to avoid creating large items in link list component.
        if(ssgaIntranetHomePage.listOfRemoveIconLinkList.get(0).isDisplayed()){
            int round;
            if(ssgaIntranetHomePage.listOfRemoveIconLinkList.size()<5) {
                round = ssgaIntranetHomePage.listOfRemoveIconLinkList.size();
            }else round = 5;

            for(int i =0; i<round;i++){
                    customizeFunctions.click(ssgaIntranetHomePage.listOfRemoveIconLinkList.get(ssgaIntranetHomePage.listOfRemoveIconLinkList.size()-1),"Delete the last item");
                    Thread.sleep(1000);
            }

        }

        test.log(LogStatus.INFO,"//Step 4: Add link item with kinds of links.");
        //Add an item with Intranet HTML article link
        customizeFunctions.click(ssgaIntranetHomePage.btnOfAddItemInLinkList,"Click on Add Item button");
        ssgaIntranetHomePage.editLinkItemWithArticleLink(ssgaIntranetHomePage.listOfLinkListItem.size(),titleHTML ,intranetHTMLArticleLink,0);


        /***
         *
         * TODO: verify the Intranet PDF Article link is available
         *
         */
        //Add an item with intranet PDF article link
//        customizeFunctions.clickByJavascript(ssgaIntranetHomePage.btnOfEditLinkList,"Click on Edit button in the link list section");
//        Thread.sleep(1000);
//        customizeFunctions.click(ssgaIntranetHomePage.btnOfAddItemInLinkList,"Click on Add Item button");
//        ssgaIntranetHomePage.editLinkItemWithArticleLink(ssgaIntranetHomePage.listOfLinkListItem.size(),titlePDF,intranetPDFArticleLink,0);

        //Add an item with intranet Video article link
        customizeFunctions.clickByJavascript(ssgaIntranetHomePage.btnOfEditLinkList,"Click on Edit button in the link list section");
        Thread.sleep(1000);
        customizeFunctions.click(ssgaIntranetHomePage.btnOfAddItemInLinkList,"Click on Add Item button");
        ssgaIntranetHomePage.editLinkItemWithArticleLink(ssgaIntranetHomePage.listOfLinkListItem.size(), titleVideo,intranetVideoArticleLink,1);

        //Add an item with SSGA shared Article link
        customizeFunctions.clickByJavascript(ssgaIntranetHomePage.btnOfEditLinkList,"Click on Edit button in the link list section");
        Thread.sleep(1000);
        customizeFunctions.click(ssgaIntranetHomePage.btnOfAddItemInLinkList,"Click on Add Item button");
        ssgaIntranetHomePage.editLinkItemWithArticleLink(ssgaIntranetHomePage.listOfLinkListItem.size(), titleShared,ssgaSharedArticleLink,0);

        //Add an item with external link. e.g Google
        customizeFunctions.clickByJavascript(ssgaIntranetHomePage.btnOfEditLinkList,"Click on Edit button in the link list section");
        Thread.sleep(1000);
        customizeFunctions.click(ssgaIntranetHomePage.btnOfAddItemInLinkList,"Click on Add Item button");

        List<WebElement> specifiedList = ssgaIntranetHomePage.locateTheSpecifiedLinksItem(ssgaIntranetHomePage.listOfLinkListItem.size());
        customizeFunctions.input(specifiedList.get(0),titleExternal,"Enter the title for this link");
        customizeFunctions.input(specifiedList.get(1),externalLink,"Enter the link URl step by step");
        customizeFunctions.click(specifiedList.get(3),"Click on selector for opening a new tab");
        customizeFunctions.click(ssgaIntranetHomePage.listOfOptionsForOpenNewTab.get(1),"choose yes option");

        test.log(LogStatus.INFO,"//Step 5: Change the color theme ");
        customizeFunctions.click(ssgaIntranetHomePage.selectorOfColorTheme,"Click on Selector of color theme");
        String currentColorTheme = ssgaIntranetHomePage.selectorOfColorTheme.getAttribute("value");
        if (currentColorTheme.equals("teal")){
            customizeFunctions.click(ssgaIntranetHomePage.listOfOptionsForColorTheme.get(1),"Choose a color theme");
        }else
            customizeFunctions.click(ssgaIntranetHomePage.listOfOptionsForColorTheme.get(0),"Choose a color theme");

        //To record the changed color theme for further verification.
        String changedColorTheme = ssgaIntranetHomePage.selectorOfColorTheme.getAttribute("value");
        customizeFunctions.click(ssgaIntranetHomePage.btnOfOKInLinkList,"Click on OK button");

        driver.switchTo().defaultContent();

        test.log(LogStatus.INFO,"//Step 6: Run workflow 'Intranet Page Activation' ");
        editIntranetArticlePage.runWorkflowInAEM("Intranet Page Activation");

        test.log(LogStatus.INFO,"//Step 7: Go to Intranet site to check links is added and all link are available in the link list.");
        navigateToIntranetSite();
        String basicWindowHandle = driver.getWindowHandle(); //Get the window handle of the home page For further verification
        Thread.sleep(8000);

        test.log(LogStatus.INFO,"//Step 6: Verify the color theme is changed successfully");
        if(changedColorTheme.equals("teal")){
            customizeAssertion.assertEquals(homePage.panelOfLinkListSection.getCssValue("background-color"),"rgba(119, 149, 155, 1)","The color theme is changed to teal");
        }else {
            customizeAssertion.assertEquals(homePage.panelOfLinkListSection.getCssValue("background-color"),"rgba(148, 186, 183, 1)","The color theme is changed to sage");

        }

        test.log(LogStatus.INFO,"//Step 6: Check all links are available in the link list");
        //Verify the intranet HTML link is available
        customizeFunctions.click(homePage.listOfLinkInLinkList.get(reusableFunctions.locateElementByText(homePage.listOfLinkInLinkList,titleHTML)),"Click on the link: " +titleHTML);
        Thread.sleep(1000);
        reusableFunctions.judgeCurrentWindow();
        customizeAssertion.assertTrue(functions.verifyLinkIsAvailableByURL(intranetHTMLArticleLink),"Verify the link is available");

        //Verify the intranet PDF link is available
        driver.switchTo().window(basicWindowHandle);
        customizeFunctions.click(homePage.listOfLinkInLinkList.get(reusableFunctions.locateElementByText(homePage.listOfLinkInLinkList,titlePDF)),"Click on the link: " + titlePDF);
        reusableFunctions.judgeCurrentWindow();
        Thread.sleep(6000);
        customizeAssertion.assertTrue(functions.verifyLinkIsAvailableByURL(intranetPDFArticleLink),"Verify the link is available");

        //Verify the intranet video link is available
        driver.switchTo().window(basicWindowHandle);
        Thread.sleep(2000);
        customizeFunctions.click(homePage.listOfLinkInLinkList.get(reusableFunctions.locateElementByText(homePage.listOfLinkInLinkList,titleVideo)),"Click on the link: " + titleVideo);
        Thread.sleep(3000);
        customizeAssertion.assertTrue(functions.verifyLinkIsAvailableByURL(intranetVideoArticleLink),"Verify the link is available");
        TestBasis.driver.navigate().back();

        //Verify the SSGA shared link is available
        customizeFunctions.click(homePage.listOfLinkInLinkList.get(reusableFunctions.locateElementByText(homePage.listOfLinkInLinkList,titleShared)),"Click on the link: " + titleShared);
        reusableFunctions.judgeCurrentWindow();
        customizeAssertion.assertTrue(functions.verifyLinkIsAvailableByURL(ssgaSharedArticleLink),"Verify the link is available");
        TestBasis.driver.switchTo().window(basicWindowHandle);

        //Verify the external link is available
        customizeFunctions.click(homePage.listOfLinkInLinkList.get(reusableFunctions.locateElementByText(homePage.listOfLinkInLinkList,titleExternal)),"Click on the link: " + titleExternal);
        Thread.sleep(2000);
        customizeAssertion.assertTrue(functions.verifyLinkIsAvailableByURL(externalLink),"Verify the link is available");

        eventualAssert();
    }
}
