package test.SSGA.Intranet.factory;

import com.relevantcodes.extentreports.LogStatus;
import org.openqa.selenium.WebElement;
import test.SSGA.Intranet.pages.LoginPage;
import test.SSGA.Intranet.testdata.CommonData;

import java.awt.*;
import java.awt.datatransfer.StringSelection;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.*;
import java.awt.event.KeyEvent;
import java.util.List;

public class ReusableFunctions extends TestBasis {
    LoginPage loginPage;
    CommonData commonData = new CommonData();



    /**
     * Login the website
     * @author He, ying
     */
    public void login(){
        loginPage = new LoginPage();
        loginPage.inputOfUsername.sendKeys(commonData.USERNAME);
        loginPage.inputOfPassword.sendKeys(commonData.PASSWORD);
        loginPage.btnOfSignIn.click();
    }


    /**
     * return the specific length of figure.
     * @param length
     * @return
     * @author He,Ying
     */
    public String getFigures(int length){
        Timestamp timestamp = new Timestamp(System.currentTimeMillis());
        String timeNow = String.valueOf(timestamp.getTime());
        String str = timeNow.substring(timeNow.length()-length);
        return str;
    }

    /**
     * locate a element by text from a list of element.
     * @param elementList
     * @param specificText
     * @return
     */
    public int locateElementByText(List<WebElement> elementList, String specificText) {
        for (int i=0;i<elementList.size();i++){
            if( elementList.get(i).getText().trim().equals(specificText)){
                return i;
            }
        }
        return -1;
    }


    /**
     *
     * when we open a new tab, we need to judge the current window for locating elements.
     * @author He, ying
     */
    public void judgeCurrentWindow() {
        String currentWindow = driver.getWindowHandle();
        Set<String> handles = driver.getWindowHandles();
        Iterator<String> it = handles.iterator();

        while (it.hasNext()) {
            String handle = it.next();
            if (currentWindow.equals(handle))
                continue;
            driver.switchTo().window(handle);

        }
    }


    /**
     * Upload a file using computer window.
     * @param fileName
     * @throws Exception
     * @author He, ying
     */
    public void uploadFile(String fileName) throws Exception {
        test.log(LogStatus.INFO,"Upload the file:" +fileName);

        String path = System.getProperty("user.dir") + "\\upload\\" +fileName;
        StringSelection stringSelection = new StringSelection(path);

        //copy the path into clipboard
        Toolkit.getDefaultToolkit().getSystemClipboard().setContents(stringSelection,null);

        Robot robot = new Robot();

        //Click Ctrl + V
        robot.keyPress(KeyEvent.VK_CONTROL);
        robot.keyPress(KeyEvent.VK_V);

        robot.keyRelease(KeyEvent.VK_CONTROL);
        robot.keyRelease(KeyEvent.VK_V);

        Thread.sleep(2000);

        robot.keyPress(KeyEvent.VK_ENTER);
        robot.keyRelease(KeyEvent.VK_ENTER);

    }

    /**
     * in the same environment, to navigate to different directory with suffix.
     * e.g: suffix is ':4502/siteadmin#/content/dam/intranet/images'
     * @param suffix
     */
    public void redirectToOtherDirectory(String suffix){
        String currentURL = driver.getCurrentUrl();
        String[] ss= currentURL.split(":");
        String newURl = ss[0]+ ":" +ss[1]+ suffix;
        driver.get(newURl);
    }

    /**
     * To get the weekday for today in Boston.
     * @return 0: Sunday, 1: Monday, 2: Tuesday, 3: Wednesday, 4: Thursday, 5: Friday, 6: Saturday
     *
     */
    public int getTheCurrentWeekDay(){
        Date localToday = new Date();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        Date bostonDay = new Date(localToday.getTime() - 12*60*60*1000);
        String day = simpleDateFormat.format(bostonDay);
        int currentWeekDay = new Date(day).getDay();
        return currentWeekDay;
    }

    /**
     * navigate to the other tab with the its web title
     * @param webTitle target web title
     * @throws Exception
     */
    public void navigateToAWebTabByWebTitle(String webTitle) throws Exception{
        int round = 0;
        Robot robot = new Robot();

        robot.keyPress(KeyEvent.VK_CONTROL);
        robot.keyPress(KeyEvent.VK_SHIFT);
        do {
            robot.keyPress(KeyEvent.VK_TAB);
            robot.keyRelease(KeyEvent.VK_TAB);
            if(TestBasis.driver.getTitle().toLowerCase().equals(webTitle.toLowerCase())) break;
            round = round +1;
        }while (round>20);

        robot.keyRelease(KeyEvent.VK_CONTROL);
        robot.keyRelease(KeyEvent.VK_SHIFT);
    }

}
