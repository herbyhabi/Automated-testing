package test.SSGA.Intranet.testcase;

import com.relevantcodes.extentreports.LogStatus;
import org.testng.annotations.Test;
import test.SSGA.Intranet.pages.EditIntranetArticlePage;
import test.SSGA.Intranet.pages.Intranet_Pages.PublicationLibPage;
import test.SSGA.Intranet.pages.WebsitesPage;
import test.SSGA.Intranet.pages.BasicPage;
import test.SSGA.Intranet.pages.Intranet_Pages.HomePage;
import test.SSGA.Intranet.factory.CustomizeAssertion;
import test.SSGA.Intranet.factory.CustomizeFunctions;
import test.SSGA.Intranet.factory.ReusableFunctions;
import test.SSGA.Intranet.factory.TestBasis;

public class TC05_CreateIntranetHTMLArticle extends TestBasis {
    WebsitesPage websitesPage;
    BasicPage basicPage;
    ReusableFunctions reusable;
    EditIntranetArticlePage editArticlePage;
    HomePage homePageOfIntranet;
    PublicationLibPage publicationLibPage;
    CustomizeFunctions actions;
    CustomizeAssertion customizeAssertion;

    /**
     * Description: Create an intranet article with Action button component and publish it into the site.
     * //Step 1: Login AEM author
     * //Step 2: Create a new Intranet article
     * //Step 3: Open the specific page
     * //Step 4: Open component options list modal box
     * //Step 5: choose Action Button Component and click on OK button
     * //Step 6: Run 'Intranet Page Activation' workflow
     * //Step 7: Go to Intranet site to check article is published
     */


    @Test
    public void verify_TC01() throws Exception {
        websitesPage = new WebsitesPage();
        basicPage = new BasicPage();
        reusable = new ReusableFunctions();
        editArticlePage = new EditIntranetArticlePage();
        homePageOfIntranet = new HomePage();
        publicationLibPage = new PublicationLibPage();
        actions = new CustomizeFunctions();
        customizeAssertion = new CustomizeAssertion();

        String pageTitle = "Test_Automated_" + reusable.getFigures(3);

        test.log(LogStatus.INFO,"//Step 1: Login AEM author");
        reusable.login();
        Thread.sleep(5000);

        test.log(LogStatus.INFO,"//Step 2: Create a new Intranet article");
        actions.click(websitesPage.toolbarOfTop.get(1),"Click on New button");
        actions.input(websitesPage.inputOfTitle,pageTitle,"Enter a title");
        Thread.sleep(2000);
        actions.click(websitesPage.itemOfPageTemplate.get(2),"Select Intranet Article template");
        actions.click(websitesPage.listOfButton.get(2),"Click on Create button");
        Thread.sleep(3000);

        test.log(LogStatus.INFO,"//Step 3: Open the specific page");
        actions.click(websitesPage.listOfItemForIntranet.get(websitesPage.listOfItemForIntranet.size()-1),"Click on the article name");
        Thread.sleep(1000);
        actions.doubleClick(websitesPage.listOfItemForIntranet.get(websitesPage.listOfItemForIntranet.size()-1),"Open the article");
        Thread.sleep(16000);

        test.log(LogStatus.INFO,"//Step 4: Open component options list modal box");

        //when navigate to a new window, we need to judge this window.
        reusable.judgeCurrentWindow();
        driver.switchTo().frame("cq-cf-frame");
        actions.doubleClick(editArticlePage.componentOfCentral,"Click on 'Drag components or assets here'");

        test.log(LogStatus.INFO,"//Step 5: choose Action Button Component and click on OK button");
        actions.click(editArticlePage.listOfComponent.get(0),"Select Action button component");
        actions.click(editArticlePage.btnOfOK,"Click on OK button");
        Thread.sleep(3000);

        driver.switchTo().defaultContent();

        test.log(LogStatus.INFO,"//Step 6: Run 'Intranet Page Activation' workflow");
        editArticlePage.runWorkflowInAEM("Intranet Page Activation");

        test.log(LogStatus.INFO,"//Step 7: Go to Intranet site to check article is published");
        navigateToIntranetSite();
        Thread.sleep(8000);

        actions.click(homePageOfIntranet.listOfHeaderMenu.get(3),"Go to Publication Library page and check the article exist");
        Thread.sleep(4000);

        for(int i =0; i<publicationLibPage.listOfArticle.size();i++){
            if(publicationLibPage.listOfArticle.get(i).getText().trim().contains(pageTitle)){
                customizeAssertion.assertTrue(true,"published the article successfully");
                break;
            }
            if(i >= publicationLibPage.listOfArticle.size()){
                customizeAssertion.assertTrue(false,"published the article successfully");
            }
        }

        eventualAssert();



    }

}