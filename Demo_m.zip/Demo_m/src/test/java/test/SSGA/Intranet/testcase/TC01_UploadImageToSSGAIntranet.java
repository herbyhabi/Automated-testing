package test.SSGA.Intranet.testcase;

import com.relevantcodes.extentreports.LogStatus;
import org.testng.annotations.Test;
import test.SSGA.Intranet.pages.WebsitesPage;
import test.SSGA.Intranet.factory.CustomizeAssertion;
import test.SSGA.Intranet.factory.CustomizeFunctions;
import test.SSGA.Intranet.factory.ReusableFunctions;
import test.SSGA.Intranet.factory.TestBasis;

public class TC01_UploadImageToSSGAIntranet extends TestBasis {
    ReusableFunctions reusable;
    WebsitesPage websitesPage;
    CustomizeFunctions actions;
    CustomizeAssertion customAssertion;

    /**
     * Description: Upload a image into the ssga Intranet/ image folder.
     * //Step 1: Navigate to Assets>SSGA Intranet>Images folder directly
     * //Step 2: Login AEM author
     * //Step 3: Click on new to upload image
     * //Step 4: Verify the image is uploaded
     */

    @Test
    public void verify_TC02() throws Exception {
        reusable = new ReusableFunctions();
        websitesPage = new WebsitesPage();
        actions = new CustomizeFunctions();
        customAssertion = new CustomizeAssertion();


        String fileName = "454343photo.png";

        test.log(LogStatus.INFO, "//Step 1: Navigate to Assets>SSGA Intranet>Images folder directly");
        reusable.redirectToOtherDirectory(":4502/siteadmin#/content/dam/intranet/images");

        test.log(LogStatus.INFO, "//Step 2: Login AEM author");
        reusable.login();
        Thread.sleep(8000);

        test.log(LogStatus.INFO, "//Step 3: Click on new to upload image");
        actions.click(websitesPage.selectorOfNew, "Click on New button");
        actions.click(websitesPage.listOfNewOptions.get(5), "Select New file option from the list.");
        actions.doubleClick(websitesPage.btnOfBrowserUploadFile, "Click on browser button");
        Thread.sleep(4000);

        reusable.uploadFile(fileName);
        actions.click(websitesPage.btnOfUploadFile, "Click on Upload button");

        //To determine if the image already exists
        if (customAssertion.doesElementExist(websitesPage.btnOfReplace)) {
            actions.click(websitesPage.btnOfReplace, "Click on replace button to replace the old image");
        }
        Thread.sleep(5000);

        test.log(LogStatus.INFO, "//Step 4: Verify the image is uploaded");
        while (websitesPage.btnOfPageNext.getCssValue("color").contains("51, 51, 51, 1")) {
            actions.click(websitesPage.btnOfPageNext, "Click on next page button to jump to the last page");
            Thread.sleep(3000);
        }

        int i;
        for ( i = 0; i < websitesPage.listOfImages.size(); i++) {
            System.out.println(websitesPage.listOfImages.get(i).getText().trim());
            if (websitesPage.listOfImages.get(i).getText().trim().equals(fileName)) {
                    customAssertion.assertTrue(true, "the image is uploaded successfully");
                    break;
            }
        }
        if(i >=websitesPage.listOfImages.size())
            customAssertion.assertTrue(false,"the image is uploaded successfully");

        eventualAssert();


    }






}