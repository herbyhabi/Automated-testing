package test.SSGA.Intranet.pages.Intranet_Pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import test.SSGA.Intranet.pages.BasicPage;

import java.util.List;

public class PublicationLibPage extends BasicPage {

    //List: list of article in Publication library page
    @FindBy(xpath="//tbody[@id = 'result_items']//tr[@class = 'article']//td/a")
    public List<WebElement> listOfArticle;
}
