package test.SSGA.Intranet.testcase;

import com.relevantcodes.extentreports.LogStatus;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import test.SSGA.Intranet.factory.CustomizeAssertion;
import test.SSGA.Intranet.factory.CustomizeFunctions;
import test.SSGA.Intranet.factory.ReusableFunctions;
import test.SSGA.Intranet.factory.TestBasis;
import test.SSGA.Intranet.pages.EditIntranetArticlePage;
import test.SSGA.Intranet.pages.Intranet_Pages.HomePage;
import test.SSGA.Intranet.pages.SSGAIntranetHomePage;
import test.SSGA.Intranet.pages.WebsitesPage;

import java.util.List;

public class TC03_EditBenchmarkBeatComponent extends TestBasis {
    ReusableFunctions reusableFunctions;
    WebsitesPage websitesPage;
    CustomizeFunctions customizeFunctions;
    SSGAIntranetHomePage ssgaIntranetHomePage;
    EditIntranetArticlePage editIntranetArticlePage;
    CustomizeAssertion customizeAssertion;
    HomePage homePage;

    /**
     * Description: Edit benchmark beat item (Today and monday), and edit Highlight
     * //Step 1: Login AEM author
     * //Step 2: Open the SSGA Intranet home page
     * //Step 3: Open Benchmark Beat component
     * //Step 4: Select the last item(monday) >> Change the link url and the label
     * //Step 5: Update the hero title and description for the Benchmark Beat Item(for today)
     * //Step 6: Click on OK to save updates
     * //Step 7: Run 'Intranet Page Activation' workflow
     * //Step 8: Go to Intranet site the home page.
     * //Step 9: Go to Intranet site the home page.
     * //Step 10: Check the hero title and description are updated in Hero section(for today)
     * //Step 11: Check the link url and label are updated in the benchmark beat for monday
     * //Step 12: Check the highlight link section is hidden
     */

    @Test
    public void verify_TC04() throws Exception {
        reusableFunctions = new ReusableFunctions();
        websitesPage = new WebsitesPage();
        customizeFunctions = new CustomizeFunctions();
        ssgaIntranetHomePage = new SSGAIntranetHomePage();
        editIntranetArticlePage = new EditIntranetArticlePage();
        customizeAssertion = new CustomizeAssertion();
        homePage = new HomePage();

        String updatedLinkUrl = "  /content/dam/intranet/media/videos/KnowledgeNow/TheTeamKNOWLEDGENOWGlobalMacro.mp4";
        int labelNum = 1;
        String updateHeroTitle = "updated Hero title" + reusableFunctions.getFigures(3);
        String updateDesc = "updated Description " + reusableFunctions.getFigures(3);

        test.log(LogStatus.INFO,"//Step 1: Login AEM author");
        reusableFunctions.login();
        Thread.sleep(5000);

        test.log(LogStatus.INFO,"//Step 2: Open the SSGA Intranet home page");
        int index = reusableFunctions.locateElementByText(websitesPage.listOfItemForIntranet,"SSGA Intranet Home");
        customizeFunctions.click(websitesPage.listOfItemForIntranet.get(index),"Click on SSGA Intranet home item");
        Thread.sleep(1000);
        customizeFunctions.doubleClick(websitesPage.listOfItemForIntranet.get(index),"Open the SSGA Intranet Home page");
        Thread.sleep(15000);

        reusableFunctions.judgeCurrentWindow();
        driver.switchTo().frame("cq-cf-frame");

        test.log(LogStatus.INFO,"//Step 3: Open Benchmark Beat component");
        customizeFunctions.doubleClick(ssgaIntranetHomePage.iconOfBenchmarkBeat,"Double click on The benchmark beat icon to open the component");
        Thread.sleep(10000);

        test.log(LogStatus.INFO,"//Step 4: Select the last item(monday) >> Change the link url and the label");
        List<WebElement> specifiedItem = ssgaIntranetHomePage.getTheSpecifiedBenchmarkBeatItem(ssgaIntranetHomePage.listOfBenchmarkBeatItem.size());
        specifiedItem.get(0).clear();
        customizeFunctions.input(specifiedItem.get(0),updatedLinkUrl,"Update the URl from PDF to video");

        //Hover over the remove icon to delete the old label.
        customizeFunctions.mouseHoverOver(ssgaIntranetHomePage.listOfRemoveLabelIcon.get(ssgaIntranetHomePage.listOfBenchmarkBeatItem.size()-1),"Hover over the specified remove icon");
        customizeFunctions.click(ssgaIntranetHomePage.listOfRemoveLabelIcon.get(ssgaIntranetHomePage.listOfBenchmarkBeatItem.size()-1),"Delete the old label");
        Thread.sleep(2000);
        customizeFunctions.click(specifiedItem.get(0),"");//Avoid some unknown error occur.

        customizeFunctions.click(ssgaIntranetHomePage.selectorOfLabel.get(ssgaIntranetHomePage.selectorOfLabel.size()-1),"Click on label selector");
        String updatedLabelName = ssgaIntranetHomePage.getLabelName(labelNum);

        customizeFunctions.click(ssgaIntranetHomePage.listOfLabelOptions.get(labelNum),"select a label from the option list");

        test.log(LogStatus.INFO,"//Step 5: Update the hero title and description for the Benchmark Beat Item(for today)  ");
        int weekday = reusableFunctions.getTheCurrentWeekDay();
        int num = ssgaIntranetHomePage.locateHeroItem(weekday);
        List<WebElement> heroItem = ssgaIntranetHomePage.getTheSpecifiedBenchmarkBeatItem(num);
        heroItem.get(3).clear(); //To remove the old hero title
        customizeFunctions.input(heroItem.get(3),updateHeroTitle,"Update the hero title");
        heroItem.get(4).clear(); //To remove the old description
        customizeFunctions.input(heroItem.get(4),updateDesc,"Update the description");

        test.log(LogStatus.INFO,"//Step 6: Edit highlight tab ");
        customizeFunctions.click(ssgaIntranetHomePage.tabOfHighlight,"Go to the highlight tab");
        boolean isChecked = ssgaIntranetHomePage.checkboxOfHide.isSelected();
        if(!isChecked) {
            customizeFunctions.clickByJavascript(ssgaIntranetHomePage.checkboxOfHide, "Click on hide checkbox");
        }

        test.log(LogStatus.INFO,"//Step 7: Click on OK to save updates ");
        customizeFunctions.click(ssgaIntranetHomePage.btnOfOK,"Click on OK button to save updates");
        Thread.sleep(8000);

        driver.switchTo().defaultContent();

        test.log(LogStatus.INFO,"//Step 8: Run 'Intranet Page Activation' workflow ");
        editIntranetArticlePage.runWorkflowInAEM("Intranet Page Activation");

        test.log(LogStatus.INFO,"//Step 9: Go to Intranet site the home page.");
        navigateToIntranetSite();
        Thread.sleep(8000);

        test.log(LogStatus.INFO,"//Step 10: Check the hero title and description are updated in Hero section(for today).");
        customizeAssertion.assertEquals(homePage.textOfHeroTitle.getText().trim(),updateHeroTitle,"The hero is updated successfully");
        customizeAssertion.assertEquals(homePage.textOfDescriptionInHero.getText().trim(),updateDesc,"The description is updated successfully");

        test.log(LogStatus.INFO,"//Step 11: Check the link url and label are updated in the benchmark beat for monday.");
        String expectedLink = ssgaIntranetHomePage.splitLinkURl(updatedLinkUrl);
        String actualLink = "";
        if(weekday == 1) {
            actualLink = homePage.linkOfURLInHero.getAttribute("href");
            customizeAssertion.assertEquals(homePage.textOfLabTitle.getText().trim().toUpperCase(), updatedLabelName.toUpperCase(), "The label is updated successfully");
        }
        if(weekday == 2) {
            actualLink = homePage.linkOfURL5.getAttribute("href");
            customizeAssertion.assertEquals(homePage.textOflabTitle5.getText().trim().toUpperCase(), updatedLabelName.toUpperCase(), "The label is updated successfully");
        }
        if(weekday == 3) {
            actualLink = homePage.linkOfURL4.getAttribute("href");
            customizeAssertion.assertEquals(homePage.textOflabTitle4.getText().trim().toUpperCase(), updatedLabelName.toUpperCase(), "The label is updated successfully");
        }
        if(weekday == 4) {
            actualLink = homePage.linkOfURL3.getAttribute("href");
            customizeAssertion.assertEquals(homePage.textOflabTitle3.getText().trim().toUpperCase(), updatedLabelName.toUpperCase(), "The label is updated successfully");
        }
        if(weekday == 5 || weekday == 6 || weekday == 0) {
            actualLink = homePage.linkOfURL2.getAttribute("href");
            customizeAssertion.assertEquals(homePage.textOflabTitle2.getText().trim().toUpperCase(), updatedLabelName.toUpperCase(), "The label is updated successfully");
        }
        customizeAssertion.assertTrue(actualLink.contains(expectedLink),"The URL is updated (Monday)");

        test.log(LogStatus.INFO,"//Step 12: Check the highlight link section is hidden");
        customizeAssertion.assertFalse(homePage.sectionOfHighlightLink.getAttribute("class").contains("inactive"),"The highlight link section is hidden");

        eventualAssert();
    }
}
