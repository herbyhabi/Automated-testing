package test.SSGA.Intranet.factory;



import java.io.File;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import static java.lang.Math.abs;

public class Functions extends TestBasis {

    /**
     *
     * @param expectedUrl
     * @return
     */
    public boolean verifyLinkIsAvailableByURL(String expectedUrl){
        String currentURL = TestBasis.driver.getCurrentUrl();
        String[] ss = expectedUrl.split("/");

        System.out.println(currentURL);
        if(currentURL.contains(ss[ss.length-1])){
           return true;
        }
        return false;
    }

    public static void deleteOldScreenshot(){
        File file = new File(".\\test-output\\errorScreenshot");
        DateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
        Date today = new Date();
        Date fileDate;
        String fileName;
        int distanceDays = 3;

        File[] fileList = file.listFiles();

        if(fileList.length > 0) {

            for (File f : fileList) {
                fileName = (f.getName().split("/"))[0];

                try{
                fileDate = dateFormat.parse(fileName);
                if (calculateNumberDay(fileDate, today) > distanceDays) {
                    f.delete();
                }
                }catch (ParseException e){
                    System.out.println("delete failed");
                }

            }
        }
    }


    /**
     * Calculate to number of days between two dates
     * @param d1
     * @param d2
     * @return
     */
    public static int calculateNumberDay(Date d1, Date d2){
        return abs((int) ((d2.getTime() - d1.getTime()) / (1000 * 60 * 60 * 24)));
    }
}
