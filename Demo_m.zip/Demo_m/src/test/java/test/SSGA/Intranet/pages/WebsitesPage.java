package test.SSGA.Intranet.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.util.List;

public class WebsitesPage extends BasicPage {


    //Item: Intranet > Article item
    @FindBy(xpath="(//li[@class ='x-tree-node'])[4]//li")
    public List<WebElement> listOfItemForIntranet;

    //Toolbar: Top toolbar
    @FindBy(xpath="(//tbody/tr[@class ='x-toolbar-left-row'])[4]//td[@class = 'x-toolbar-cell']//table")
    public List<WebElement> toolbarOfTop;

    //Selector: New selector in top toolbar
    @FindBy(xpath="((//tbody/tr[@class ='x-toolbar-left-row'])[4]//td[@class = 'x-toolbar-cell']//table//td[@class = 'x-btn-mr'])[2]")
    public WebElement selectorOfNew;

    //List: Options list matched with New selector
    @FindBy(xpath="//ul[@class = 'x-menu-list']//li")
    public List<WebElement> listOfNewOptions;

    //Tab: Tag tab
    @FindBy(xpath="//button[@class = ' x-btn-text cq-switcher-tagadmin-inactive']")
    public List<WebElement> tabOfTag;

    /**
     * New File modal box
     */
    //Button: Browser button for uploading New file
    @FindBy(xpath="//div[@class = 'x-panel-body x-panel-body-noheader']//button[@class = ' x-btn-text']")
    public WebElement btnOfBrowserUploadFile;

    //Button: Upload button on the new file modal box
    @FindBy(xpath="//button[text() = 'Upload']")
    public WebElement btnOfUploadFile;

    //Button: Replace button on the new file modal box
    @FindBy(xpath="//td[@class = 'x-toolbar-left']//button[text() = 'Replace']")
    public WebElement btnOfReplace;

    //List: image list in the images folder
    @FindBy(xpath="//div[@class = 'x-grid3-body']//div[contains(@class, 'x-grid3-row')]//td//div[@class = 'x-grid3-cell-inner x-grid3-col-name']")
    public List<WebElement> listOfImages;

    //Button: Page next button
    @FindBy(xpath="//button[@class = ' x-btn-text x-tbar-page-next']")
    public WebElement btnOfPageNext;

    /***************/

    /**
     *
     * Create New modal box
     *
     */
    //Input: title input in Create page
    @FindBy(xpath="//input[@name= 'title']")
    public WebElement inputOfTitle;

    //Item: page template
    @FindBy(xpath="//div[contains(@class, 'template-item')]")
    public List<WebElement> itemOfPageTemplate;

    //Button: Create button
    @FindBy(xpath="//td[@class = 'x-toolbar-right']//button[@type = 'button']")
    public List<WebElement> listOfButton;
    /****************/



}
