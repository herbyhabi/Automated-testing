package test.SSGA.Intranet.factory;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.testng.ITestResult;
import org.testng.TestListenerAdapter;

import java.io.File;
import java.io.IOException;

public class screenshotListener extends TestListenerAdapter {
    private Log log = LogFactory.getLog(this.getClass());

    @Override
    public void onTestFailure(ITestResult result){
        File directory = new File("test-output");
        try{
            String screenPath = directory.getCanonicalPath() + "/";
            File file = new File(screenPath);
            if(!file.exists()){
                file.mkdirs();
            }
            String fileName = result.getMethod().getMethodName()+".png";

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
