package test.SSGA.Intranet.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import test.SSGA.Intranet.factory.CustomizeFunctions;
import test.SSGA.Intranet.factory.ReusableFunctions;

import java.util.List;

public class EditIntranetArticlePage extends BasicPage {


    //Box: central component for open 'Insert new component' modal box
    @FindBy(xpath="(//span[contains(text(), 'Drag components')])[1]")
    public WebElement componentOfCentral;

    //List: Component list.
    @FindBy(xpath="//table//button[contains(text(),'Component')]")
    public List<WebElement> listOfComponent;

    //Button: Ok button in 'Insert new components' modal box.
    @FindBy(xpath="//div[@class = 'x-window-bwrap']//button[contains(text(),'OK')]")
    public WebElement btnOfOK;


    /**
     *
     * elements of AEM modal box
     *
     */

    //List: List of header toolbar in the 'AEM' modal box.
    @FindBy(xpath="//div[@id= 'cq-sk-tabpanel']//div[contains(@class, 'x-tab-panel-header')]//li")
    public List<WebElement> listOfHeaderInAEMModalBox;

    //Selector: Workflow type selector
    @FindBy(xpath="(//div[@class = 'x-window-mc']//div[@class = 'x-form-element']//input)[2]")
    public WebElement selectorOfWorkflowType;

    //List: List of workflow type item
    @FindBy(xpath="//div[@class = 'x-combo-list-inner']//div[contains(@class,'x-combo-list-item')]")
    public List<WebElement> listOfWorkflowItem;

    //Button: Start Workflow Button
    @FindBy(xpath="//table[@id = 'cq.sidekick.workflow.start']//button[@type = 'button']")
    public WebElement btnOfStartWorkflow;

    //Button: Complete button during running workflow
    @FindBy(xpath="//div[@id= 'cq-sk-tab-WORKFLOW']//table[1]")
    public WebElement btnOfCompleteWorkflow;

    //Button: OK button on the 'Complete Work Item' box.
    @FindBy(xpath="//div[@class = 'x-window-footer x-panel-btns']//button[1]")
    public WebElement btnOfOKOnCompleteWorkItemBox;

    //Button: button of Go to AEM website
    @FindBy(xpath="//tr[@class= 'x-toolbar-left-row']//button[@class = ' x-btn-text cq-sidekick-siteadmin']")
    public WebElement btnOfGoToWebsite;

    /********************/

    public void runWorkflowInAEM(String workflowName) throws Exception {
        CustomizeFunctions actions = new CustomizeFunctions();
        ReusableFunctions reusable = new ReusableFunctions();

        actions.click(listOfHeaderInAEMModalBox.get(4),"Go to workflow tab in AEM modal box");
        actions.doubleClick(selectorOfWorkflowType,"Click on selector of workflow type");
        Thread.sleep(3000);

        int workFlowIndex = reusable.locateElementByText(listOfWorkflowItem,workflowName);
        actions.click(listOfWorkflowItem.get(workFlowIndex),"Select 'Intranet Page Activation' workflow");
        actions.click(btnOfStartWorkflow,"Click on Start Workflow button");
        Thread.sleep(8000);

        actions.click(btnOfCompleteWorkflow,"Click on Complete workflow button");
        actions.click(btnOfOKOnCompleteWorkItemBox,"Click on OK button on the complete work Item box");
        Thread.sleep(3000);

        actions.click(btnOfCompleteWorkflow,"Click on Complete workflow button");
        actions.click(btnOfOKOnCompleteWorkItemBox,"Click on OK button on the complete work Item box");
        Thread.sleep(5000);
    }

}
