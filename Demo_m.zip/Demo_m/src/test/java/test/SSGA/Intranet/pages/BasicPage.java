package test.SSGA.Intranet.pages;

import org.openqa.selenium.support.PageFactory;
import test.SSGA.Intranet.factory.TestBasis;


public class BasicPage {


    public BasicPage() {
        PageFactory.initElements(TestBasis.driver, this);
    }





}